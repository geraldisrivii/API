<?php

require_once "helpers.php";
require_once "functions/GET_functions.php";
require_once "functions/POST_functions.php";
require_once "functions/LINK_functions.php";
require_once "functions/DELETE_functions.php";
require_once "functions/PATCH_functions.php";